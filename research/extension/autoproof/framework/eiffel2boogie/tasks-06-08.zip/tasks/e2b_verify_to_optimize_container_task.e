note
	description: "Task to re-verify with optimization."

class
	E2B_VERIFY_TO_OPTIMIZE_CONTAINER_TASK

inherit

	E2B_VERIFY_TASK

	E2B_SHARED_CONTEXT

create
	make

feature {NONE} -- Initialization

	make (a_boogie_universe: IV_UNIVERSE; a_target_class: CLASS_C; a_target_feature: FEATURE_I; a_target_variable: STRING_32; a_failed_verifications: READABLE_INDEXABLE [E2B_FAILED_VERIFICATION]; a_tasks: like remaining_tasks)
			-- Initialize task.
		do
			print("run E2B_VERIFY_TO_OPTIMIZE_CONTAINER_TASK.make%N")
			target_class := a_target_class
			target_feature := a_target_feature
			target_variable := a_target_variable

			failed_verifications := a_failed_verifications

			remaining_tasks := a_tasks
            l_boogie_universe := a_boogie_universe

   			has_next_step := True
		end

feature -- Status report

	has_next_step: BOOLEAN
			-- <Precursor>

	sleep_time: NATURAL = 0
			-- <Precursor>

    l_boogie_universe: IV_UNIVERSE

    failed_verifications: READABLE_INDEXABLE [E2B_FAILED_VERIFICATION]
            -- Verification failures

feature {ROTA_S, ROTA_TASK_I} -- Basic operations

	step
			-- <Precursor>
		local
			i, v: INTEGER
			element_type: TYPE_A
		do
			print("run E2B_VERIFY_TO_OPTIMIZE_CONTAINER_TASK.step%N")

			remaining_tasks.extend (create {E2B_VERIFY_TO_OPTIMIZE_INTEGER_TASK}.make (l_boogie_universe, target_class, target_feature, target_variable + ".count", failed_verifications, remaining_tasks))

            v := get_minimized_container_size

            -- a_type.actual_type
            element_type := get_element_type

			from
				i := 1
			until
				i > v
			loop
				-- minimize_var (a_var + "[" + i.out + "]", a_type.actual_type)
			    remaining_tasks.extend (create {E2B_VERIFY_TO_OPTIMIZE_VAR_TASK}.make (l_boogie_universe, target_class, target_feature, target_variable + "[" + i.out + "]", element_type, failed_verifications, remaining_tasks))
			    i := i + 1
			end

			has_next_step := False
		end

	cancel
			-- <Precursor>
		do
			has_next_step := False
		end

feature {NONE} -- Implementation

	remaining_tasks: attached LINKED_LIST [ROTA_TASK_I]
			-- List of remaining tasks.

	target_variable: STRING_32
			-- Variable under optimization

	target_feature: detachable FEATURE_I
			-- Feature under optimization

	target_class: detachable CLASS_C
			-- Class of the target feature

feature
	get_minimized_container_size: INTEGER
	        -- Get the minimized container size from counterexample model
	do
        Result := 10
	end

	get_element_type: TYPE_A
	       -- Get the type of the element of the container
	do
		--
	end

note
	date: "$Date: 2022-01-18 20:46:44 +0100 (Tue, 18 Jan 2022) $"
	revision: "$Revision: 106120 $"
	copyright:
		"Copyright (c) 2012-2014 ETH Zurich",
		"Copyright (c) 2018 Politecnico di Milano",
		"Copyright (c) 2022 Schaffhausen Institute of Technology"
	author: "Julian Tschannen", "Alexander Kogtenkov"
	license: "GNU General Public License"
	license_name: "GPL"
	EIS: "name=GPL", "src=https://www.gnu.org/licenses/gpl.html", "tag=license"
	copying: "[
					This program is free software; you can redistribute it and/or modify it under the terms of
					the GNU General Public License as published by the Free Software Foundation; either version 1,
					or (at your option) any later version.
			
					This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
					without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
					See the GNU General Public License for more details.
			
					You should have received a copy of the GNU General Public License along with this program.
					If not, see <https://www.gnu.org/licenses/>.
		]"

end
