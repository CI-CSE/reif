note
	description: "Task to re-verify with optimization."

class
	E2B_VERIFY_TO_OPTIMIZE_VAR_TASK

inherit

	E2B_VERIFY_TASK

	E2B_SHARED_CONTEXT

create
	make

feature {NONE} -- Initialization

	make (a_boogie_universe: IV_UNIVERSE; a_target_class: CLASS_C; a_target_feature: FEATURE_I; a_target_variable: STRING_32; a_var_type: TYPE_A; a_failed_verifications: READABLE_INDEXABLE [E2B_FAILED_VERIFICATION]; a_tasks: like remaining_tasks)
			-- Initialize task.
		do
			print("run E2B_VERIFY_TO_OPTIMIZE_VAR_TASK.make%N")
			target_class := a_target_class
			target_feature := a_target_feature
			target_variable := a_target_variable
            var_type := a_var_type

			failed_verifications := a_failed_verifications

            -- initial_result_generator := a_initial_result_generator
			remaining_tasks := a_tasks

			has_next_step := True

            l_boogie_universe := a_boogie_universe
			-- create l_boogie_universe.make
			-- boogie_universe_cell.put (l_boogie_universe)
		end

feature -- Status report

	has_next_step: BOOLEAN
			-- <Precursor>

	sleep_time: NATURAL = 0
			-- <Precursor>

    l_boogie_universe: IV_UNIVERSE

    failed_verifications: READABLE_INDEXABLE [E2B_FAILED_VERIFICATION]
            -- Verification failures

	-- initial_result_generator: attached E2B_RESULT_GENERATOR
	        -- Result generator of the initial verification


feature {ROTA_S, ROTA_TASK_I} -- Basic operations

	step
			-- <Precursor>
		-- local
		--	l_boogie_universe: IV_UNIVERSE
		local
			type: STRING_32
		do
			print("run E2B_VERIFY_TO_OPTIMIZE_VAR_TASK.step%N")
					-- Minimize a variable
			type := var_type.base_class.name
			if is_integer_type (type) then -- Minimize integer
				remaining_tasks.extend (create {E2B_VERIFY_TO_OPTIMIZE_INTEGER_TASK}.make (l_boogie_universe, target_class, target_feature, target_variable, failed_verifications, remaining_tasks))
			elseif is_reference_type (type) then
				remaining_tasks.extend (create {E2B_VERIFY_TO_OPTIMIZE_REFERENCE_TASK}.make (l_boogie_universe, target_class, target_feature, target_variable, var_type, failed_verifications, remaining_tasks))
			end
		    has_next_step := False
		end

	cancel
			-- <Precursor>
		do
			has_next_step := False
		end

feature {NONE} -- Implementation

	remaining_tasks: attached LINKED_LIST [ROTA_TASK_I]
			-- List of remaining tasks.

	target_feature: detachable FEATURE_I
			-- Feature under optimization

	target_class: detachable CLASS_C
			-- Class of the target feature

	target_variable: STRING_32
			-- Variable under optimization

    var_type: TYPE_A
            -- Type of the target variable

feature {NONE} -- Type checking

    is_integer_type (a_type: STRING_32): BOOLEAN
			-- Is `a_type' an integer type?
		do
			Result := a_type.same_string ("INTEGER") or a_type.same_string ("INTEGER_8") or a_type.same_string ("INTEGER_16") or a_type.same_string ("INTEGER_32")
		end

	is_reference_type (a_type: STRING_32): BOOLEAN
			-- Is 	`a_type' a reference type?
		do
			Result := not is_integer_type (a_type)
		end

note
	date: "$Date: 2022-01-18 20:46:44 +0100 (Tue, 18 Jan 2022) $"
	revision: "$Revision: 106120 $"
	copyright:
		"Copyright (c) 2012-2014 ETH Zurich",
		"Copyright (c) 2018 Politecnico di Milano",
		"Copyright (c) 2022 Schaffhausen Institute of Technology"
	author: "Julian Tschannen", "Alexander Kogtenkov"
	license: "GNU General Public License"
	license_name: "GPL"
	EIS: "name=GPL", "src=https://www.gnu.org/licenses/gpl.html", "tag=license"
	copying: "[
					This program is free software; you can redistribute it and/or modify it under the terms of
					the GNU General Public License as published by the Free Software Foundation; either version 1,
					or (at your option) any later version.
			
					This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
					without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
					See the GNU General Public License for more details.
			
					You should have received a copy of the GNU General Public License along with this program.
					If not, see <https://www.gnu.org/licenses/>.
		]"

end
