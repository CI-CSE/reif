note
	description: "[
		Translation unit for the signature of an Eiffel routine.
	]"
	date: "$Date: 2013-10-21 23:20:06 +0800 (Mon, 21 Oct 2013) $"
	revision: "$Revision: 93152 $"

class
	E2B_TU_ROUTINE_SIGNATURE

inherit

	E2B_TU_FEATURE

create
	make

feature -- Access

	base_id: STRING = "routine-signature"
			-- <Precursor>

feature -- Basic operations

	translate
			-- <Precursor>
		local
			l_translator: E2B_ROUTINE_TRANSLATOR
		do
			create l_translator.make
			print("translate routine:" + feat.feature_name_32.to_string_8 + "%N")
			l_translator.translate_routine_signature (feat, type)
		end

note
	license: "GNU General Public License"
	license_name: "GPL"
	EIS: "name=GPL", "src=https://www.gnu.org/licenses/gpl.html", "tag=license"
	copying: "[
		This program is free software; you can redistribute it and/or modify it under the terms of
		the GNU General Public License as published by the Free Software Foundation; either version 1,
		or (at your option) any later version.

		This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
		without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
		See the GNU General Public License for more details.

		You should have received a copy of the GNU General Public License along with this program.
		If not, see <https://www.gnu.org/licenses/>.
	]"
end
