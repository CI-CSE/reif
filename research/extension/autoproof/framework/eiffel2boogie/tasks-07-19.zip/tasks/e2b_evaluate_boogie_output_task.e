note
	description: "Task to evaluate Boogie output."
	date: "$Date: 2013-12-06 00:42:21 +0800 (Fri, 06 Dec 2013) $"
	revision: "$Revision: 93627 $"

class
	E2B_EVALUATE_BOOGIE_OUTPUT_TASK

inherit

	ROTA_TASK_I

create
	make

feature {NONE} -- Initialization

	make (a_verifier: attached like verifier; a_result_generator: like result_generator)
			-- Initialize task.
		do
			print("run E2B_EVALUATE_BOOGIE_OUTPUT_TASK.make%N")
			verifier := a_verifier
			result_generator := a_result_generator
			has_next_step := True
		end

feature -- Status report

	has_next_step: BOOLEAN
			-- <Precursor>

	is_interface_usable: BOOLEAN = True
			-- <Precursor>

feature {ROTA_S, ROTA_TASK_I} -- Basic operations

	step
			-- <Precursor>
		do
			print("run E2B_EVALUATE_BOOGIE_OUTPUT_TASK.step%N")
			if attached verifier.last_output then
				verifier.parse_verification_output
				result_generator.process_boogie_result (verifier.last_result)
			end
			verifier.helper.options.set_last_result (result_generator.last_result)
			has_next_step := False
		end

	cancel
			-- <Precursor>
		do
			has_next_step := False
		end

feature {NONE} -- Implementation

	verifier: attached E2B_VERIFIER
			-- Boogie verifier.

	result_generator: attached E2B_RESULT_GENERATOR
			-- Result generator.

;note
	license: "GNU General Public License"
	license_name: "GPL"
	EIS: "name=GPL", "src=https://www.gnu.org/licenses/gpl.html", "tag=license"
	copying: "[
		This program is free software; you can redistribute it and/or modify it under the terms of
		the GNU General Public License as published by the Free Software Foundation; either version 1,
		or (at your option) any later version.

		This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
		without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
		See the GNU General Public License for more details.

		You should have received a copy of the GNU General Public License along with this program.
		If not, see <https://www.gnu.org/licenses/>.
	]"
end
